// For demo purposes, using simple hardcoded credentials
// In production, connect to your database
export let users = [
  {
    id: "1",
    name: "John Doe",
    email: "john@example.com",
    password: "password123",
    image: "https://placehold.co/60x60/0f172a/white?text=JD",
  },
  {
    id: "2",
    name: "Jane Smith",
    email: "jane@example.com",
    password: "password123",
    image: "https://placehold.co/60x60/0f172a/white?text=JS",
  },
];