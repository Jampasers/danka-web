// src/app/api/auth/[...nextauth]/route.ts
import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

const handler = NextAuth({
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        // 👇 Ganti ini dengan logika validasi login-mu
        if (!credentials?.email || !credentials?.password) {
          return null;
        }

        // Contoh: cek ke database (dummy)
        if (
          credentials.email === "user@example.com" &&
          credentials.password === "123456"
        ) {
          return {
            id: "1",
            email: credentials.email,
            name: "User",
          };
        }

        // Jika gagal → return null
        return null;
      },
    }),
  ],
  session: {
    strategy: "jwt", // wajib kalau pakai Credentials
  },
  pages: {
    signIn: "/login", // arahkan ke halaman login custom
  },
  secret: process.env.NEXTAUTH_SECRET,
});

// Export GET dan POST
export { handler as GET, handler as POST };
